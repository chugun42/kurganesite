// ======================================================================
// Данные: реальные места Кургана (координаты OpenStreetMap)
// ======================================================================
const PLACES = [
  {
    id: 'lenin',
    name: 'Площадь Ленина',
    addr: 'Центр Кургана',
    lat: 55.44075,
    lon: 65.34145,
    info: 'Градостроительный ансамбль 1950-х годов — сердце города и удобная точка старта любой прогулки.'
  },
  {
    id: 'theatre',
    name: 'Курганский театр драмы',
    addr: 'ул. Гоголя, 58',
    lat: 55.44095,
    lon: 65.34439,
    info: 'Классический портик с колоннами — одна из самых узнаваемых картинок Кургана.'
  },
  {
    id: 'garden',
    name: 'Городской сад им. Александра Невского',
    addr: 'ул. Ленина, 23',
    lat: 55.43911,
    lon: 65.34381,
    info: 'Старейший парк в центре: тенистые аллеи, скамейки и скульптура «Родители».'
  },
  {
    id: 'museum',
    name: 'Краеведческий музей',
    addr: 'ул. Пушкина, 137',
    lat: 55.44051,
    lon: 65.33737,
    info: 'Областной краеведческий музей, а рядом — Вечный огонь и бюст М.С. Шумилова.'
  },
  {
    id: 'pushkin',
    name: 'Улица Пушкина',
    addr: 'пешеходная часть, центр',
    lat: 55.43967,
    lon: 65.33659,
    info: 'Тихая улица в центре: магазины, кофейни и вечерние прогулки местных жителей.'
  },
  {
    id: 'cinema',
    name: 'Кинотеатр «Россия»',
    addr: 'ул. Гоголя',
    lat: 55.43887,
    lon: 65.33845,
    info: 'Старый кинотеатр в центре: вечерние сеансы и афиша, которую помнят несколько поколений.'
  },
  {
    id: 'kuybyshev',
    name: 'Улица Куйбышева',
    addr: 'историческая часть города',
    lat: 55.43711,
    lon: 65.35352,
    info: 'Главная улица старого купеческого Кургана: особняки XIX века, витрины и трамвайные рельсы.'
  },
  {
    id: 'fire',
    name: 'Пожарная часть №9 (каланча)',
    addr: 'ул. Куйбышева, 62',
    lat: 55.43545,
    lon: 65.35123,
    info: 'Деревянная каланча 1881 года — один из символов дореволюционного Кургана.'
  },
  {
    id: 'kuchel',
    name: 'Дом-музей В.К. Кюхельбекера',
    addr: 'ул. Куйбышева, 19',
    lat: 55.431,
    lon: 65.34084,
    info: 'Деревянный дом, где жил поэт-декабрист Вильгельм Кюхельбекер, сосланный в Курган.'
  },
  {
    id: 'decembrists',
    name: 'Дом-музей декабристов',
    addr: 'ул. Климова, 80а',
    lat: 55.43461,
    lon: 65.3535,
    info: 'Мемориальное место, связанное с пребыванием в Кургане декабриста М.М. Нарышкина.'
  },
  {
    id: 'troitsa',
    name: 'Свято-Троицкий собор',
    addr: 'ул. Климова',
    lat: 55.43509,
    lon: 65.35514,
    info: 'Храм в исторической части города — тихая точка для прогулки по вечерам.'
  },
  {
    id: 'philharmonic',
    name: 'Курганская филармония',
    addr: 'Троицкая площадь, 1',
    lat: 55.43625,
    lon: 65.35478,
    info: 'Концертный зал на Троицкой площади: классика, джаз и городские оркестры.'
  },
  {
    id: 'park',
    name: 'Парк Победы',
    addr: 'западная часть города',
    lat: 55.43424,
    lon: 65.31835,
    info: 'Парк с мемориалами и видами на Тобол — отсюда начинается спуск к реке.'
  },
  {
    id: 'tobol',
    name: 'Берег Тобола',
    addr: 'спуск от Парка Победы',
    lat: 55.4287,
    lon: 65.3155,
    info: 'Тихий берег реки: вода, фонари и отражения — самое «водное» место маршрута.'
  },
  {
    id: 'station',
    name: 'ДК железнодорожников',
    addr: 'ул. Станционная, 5',
    lat: 55.44021,
    lon: 65.31883,
    info: 'Дворец культуры у привокзальной площади, рядом — памятник первому паровозу.'
  },
  {
    id: 'lokomotiv',
    name: 'Памятник первому паровозу',
    addr: 'привокзальная площадь',
    lat: 55.4423,
    lon: 65.3238,
    info: 'Копия паровоза братьев Черепановых — традиционное место для фото в дороге.'
  },
  {
    id: 'nevsky',
    name: 'Собор Александра Невского',
    addr: 'ул. Володарского, 42',
    lat: 55.43902,
    lon: 65.34268,
    info: 'Главный храм города в двух шагах от Городского сада: колокольня, тихий двор и вечерняя подсветка.'
  },
  {
    id: 'artmuseum',
    name: 'Областной художественный музей',
    addr: 'ул. Куйбышева, 129',
    lat: 55.44101,
    lon: 65.35355,
    info: 'Живопись, иконы и графика в старом купеческом особняке — один из самых спокойных залов города.'
  },
  {
    id: 'citymuseum',
    name: 'Музей истории города Кургана',
    addr: 'ул. Куйбышева, 59',
    lat: 55.43471,
    lon: 65.34865,
    info: 'Небольшой музей о том, как деревянный острог стал городом: старые карты, фотографии и вещи горожан.'
  },
  {
    id: 'gulliver',
    name: 'Театр кукол «Гулливер»',
    addr: 'ул. Советская, 104',
    lat: 55.43686,
    lon: 65.35068,
    info: 'Кукольный театр с яркой афишей: сюда ходят и с детьми, и без — на вечерние спектакли.'
  },
  {
    id: 'epiphany',
    name: 'Богоявленский кафедральный собор',
    addr: 'ул. Климова, 3',
    lat: 55.42923,
    lon: 65.34073,
    info: 'Кафедральный собор на юге центра: белые стены, звонница и тихие улицы вокруг.'
  },
  {
    id: 'market',
    name: 'Центральный рынок',
    addr: 'ул. Куйбышева, 74',
    lat: 55.4379,
    lon: 65.35867,
    info: 'Утренний рынок города: ягоды, мёд, домашний сыр и разговоры продавцов между рядами.'
  },
  {
    id: 'afghan',
    name: 'Памятник воинам-интернационалистам',
    addr: 'ул. Карла Маркса',
    lat: 55.44269,
    lon: 65.35298,
    info: 'Мемориал в сквере на Карла Маркса — тихое место с бронзой и списками имён.'
  },
  {
    id: 'argentovskaya',
    name: 'Памятник Н. Аргентовской',
    addr: 'Троицкая площадь',
    lat: 55.43621,
    lon: 65.35349,
    info: 'Памятник врачу-революционерке на Троицкой площади, среди старых купеческих кварталов.'
  },
  {
    id: 'ksu',
    name: 'Курганский госуниверситет',
    addr: 'ул. Советская, 63',
    lat: 55.43466,
    lon: 65.34278,
    info: 'Главный корпус КГУ: студенты, скверы и кофейни — обычная городская жизнь в будний вечер.'
  }
];

// Три маршрута: реальная трасса лежит в routes.js (построена по улицам OpenStreetMap)
const ROUTES = [
  {
    id: 'center',
    kind: 'Маршрут 01',
    title: 'Купеческий центр',
    desc: 'Прогулка по старой части города: площадь Ленина, театр, пожарная каланча, купеческие особняки на Куйбышева, дом-музей декабристов и Троицкий собор.',
    km: '3,4',
    min: '50',
    stops: ['lenin', 'theatre', 'fire', 'kuybyshev', 'decembrists', 'troitsa']
  },
  {
    id: 'green',
    kind: 'Маршрут 02',
    title: 'Зелёный Курган',
    desc: 'Компактная прогулка по центру: Городской сад, кинотеатр «Россия», улица Пушкина, краеведческий музей и площадь Ленина. Полтора километра, всё рядом.',
    km: '1,5',
    min: '25',
    stops: ['garden', 'cinema', 'pushkin', 'museum', 'lenin']
  },
  {
    id: 'river',
    kind: 'Маршрут 03',
    title: 'Вечерний берег Тобола',
    desc: 'Маршрут к воде: от Парка Победы вниз к Тоболу, вдоль берега и обратно через ДК железнодорожников к памятнику первого паровоза.',
    km: '5,1',
    min: '70',
    stops: ['park', 'tobol', 'station', 'lokomotiv']
  }
];

// ======================================================================
// Появление элементов при скролле
// ======================================================================
const revealElements = document.querySelectorAll('.reveal');

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('active');
      revealObserver.unobserve(entry.target);
    }
  });
}, {
  threshold: 0.15
});

revealElements.forEach((element) => revealObserver.observe(element));

// ======================================================================
// Прогресс списка «настроений» при скролле
// ======================================================================
const routeProgress = document.getElementById('routeProgress');
const routeSection = document.getElementById('route');

function updateRouteProgress() {
  if (!routeProgress || !routeSection) return;

  const rect = routeSection.getBoundingClientRect();
  const total = rect.height - window.innerHeight;
  const passed = Math.min(Math.max(-rect.top, 0), total);
  const percent = total > 0 ? (passed / total) * 100 : 0;

  routeProgress.style.height = `${percent}%`;
}

window.addEventListener('scroll', updateRouteProgress);
window.addEventListener('resize', updateRouteProgress);
updateRouteProgress();

// ======================================================================
// Интерактивные окна: текст + настоящая фотография
// ======================================================================
const windowButtons = document.querySelectorAll('.window');
const windowText = document.getElementById('windowText');
const windowPhoto = document.getElementById('windowPhoto');
const windowCaption = document.getElementById('windowCaption');

function showWindow(windowItem) {
  windowButtons.forEach((item) => item.classList.remove('active'));
  windowItem.classList.add('active');

  const text = windowItem.dataset.text || '';
  const img = windowItem.dataset.img || '';
  const caption = windowItem.dataset.caption || '';

  if (windowText) {
    windowText.style.opacity = '0';

    setTimeout(() => {
      windowText.textContent = text;
      windowText.style.opacity = '1';
    }, 250);
  }

  if (windowPhoto && img && windowPhoto.getAttribute('src') !== img) {
    windowPhoto.style.opacity = '0';

    const preload = new Image();
    preload.onload = () => {
      windowPhoto.src = img;
      windowPhoto.alt = caption;
      windowPhoto.style.opacity = '1';
    };
    preload.src = img;
  }

  if (windowCaption) {
    windowCaption.textContent = caption;
  }
}

windowButtons.forEach((windowItem) => {
  if (windowItem.dataset.img) {
    windowItem.style.setProperty('--win-img', `url("${windowItem.dataset.img}")`);
  }

  windowItem.addEventListener('click', () => showWindow(windowItem));
});

// ======================================================================
// Переключение светлой и ночной темы
// ======================================================================
const themeToggle = document.getElementById('themeToggle');
const themeIcon = themeToggle ? themeToggle.querySelector('.theme-icon') : null;

if (themeToggle) {
  let savedTheme = '';

  try {
    savedTheme = localStorage.getItem('kurganTheme') || '';
  } catch (error) {
    savedTheme = '';
  }

  if (savedTheme === 'light') {
    document.body.classList.add('light');
    if (themeIcon) themeIcon.textContent = '☀️';
  }

  themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('light');

    const isLight = document.body.classList.contains('light');
    if (themeIcon) themeIcon.textContent = isLight ? '☀️' : '🌙';

    try {
      localStorage.setItem('kurganTheme', isLight ? 'light' : 'night');
    } catch (error) {
      /* хранилище недоступно — тема всё равно переключится */
    }
  });
}

// ======================================================================
// Параллакс для первого экрана
// ======================================================================
const heroContent = document.querySelector('.hero-content');
const moon = document.querySelector('.moon');
const city = document.querySelector('.city');

window.addEventListener('scroll', () => {
  const scrollY = window.scrollY;

  if (scrollY < window.innerHeight && heroContent && moon && city) {
    heroContent.style.transform = `translateY(${scrollY * 0.18}px)`;
    heroContent.style.opacity = `${1 - scrollY / (window.innerHeight * 0.9)}`;
    moon.style.transform = `translateY(${scrollY * 0.1}px)`;
    city.style.transform = `translateY(${scrollY * 0.05}px)`;
  }
});

// ======================================================================
// Дневник прохожего: прокрутка карточек
// ======================================================================
const diaryTrack = document.getElementById('diaryTrack');
const diaryPrev = document.getElementById('diaryPrev');
const diaryNext = document.getElementById('diaryNext');

if (diaryTrack && diaryPrev && diaryNext) {
  diaryPrev.addEventListener('click', () => {
    diaryTrack.scrollBy({ left: -380, behavior: 'smooth' });
  });

  diaryNext.addEventListener('click', () => {
    diaryTrack.scrollBy({ left: 380, behavior: 'smooth' });
  });
}

// ======================================================================
// Вспомогательные функции
// ======================================================================
function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function placeById(id) {
  return PLACES.find((place) => place.id === id);
}

function yandexPointLink(lat, lon) {
  return `https://yandex.ru/maps/?pt=${lon},${lat}&z=17`;
}

function yandexRouteLink(stops) {
  const points = stops
    .map((id) => placeById(id))
    .filter(Boolean)
    .map((place) => `${place.lat},${place.lon}`)
    .join('~');

  return `https://yandex.ru/maps/?rtext=${points}&rtt=pd`;
}

function readStorage(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (error) {
    return fallback;
  }
}

function writeStorage(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (error) {
    return false;
  }
}

// ======================================================================
// Настоящие маршруты + карта Яндекс.Карты
// ======================================================================
const routeTabs = document.querySelectorAll('.route-tab');
const routeKind = document.getElementById('routeKind');
const routeName = document.getElementById('routeName');
const routeDesc = document.getElementById('routeDesc');
const routeKm = document.getElementById('routeKm');
const routeMin = document.getElementById('routeMin');
const routeStopsCount = document.getElementById('routeStopsCount');
const routeStopsList = document.getElementById('routeStops');
const routeLink = document.getElementById('routeLink');

let routeMap = null;
let placesMap = null;
let routeMarkers = [];
let activeRoute = 0;

function mapFallback(element, message) {
  if (element) {
    element.innerHTML = `<div class="map-fallback">${message}</div>`;
  }
}

function initRouteMap(onReady) {
  const element = document.getElementById('routeMap');

  if (!element) {
    if (onReady) onReady();
    return;
  }

  if (typeof ymaps === 'undefined') {
    mapFallback(
      element,
      'Карта не загрузилась (нужен интернет).<br>Все точки маршрута описаны списком слева.'
    );
    if (onReady) onReady();
    return;
  }

  ymaps.ready(() => {
    routeMap = new ymaps.Map(element, {
      center: [55.44, 65.34],
      zoom: 13,
      controls: ['zoomControl']
    });

    routeMap.behaviors.disable('scrollZoom');

    if (onReady) onReady();
  });
}

function drawRoute(index) {
  const route = ROUTES[index];
  if (!route) return;

  activeRoute = index;

  if (routeKind) routeKind.textContent = route.kind;
  if (routeName) routeName.textContent = route.title;
  if (routeDesc) routeDesc.textContent = route.desc;
  if (routeKm) routeKm.textContent = route.km;
  if (routeMin) routeMin.textContent = route.min;
  if (routeStopsCount) routeStopsCount.textContent = String(route.stops.length);

  if (routeStopsList) {
    routeStopsList.innerHTML = route.stops.map((id) => {
      const place = placeById(id);
      if (!place) return '';
      return `<li><strong>${escapeHtml(place.name)}</strong><span>${escapeHtml(place.addr)}</span></li>`;
    }).join('');
  }

  const first = placeById(route.stops[0]);
  const last = placeById(route.stops[route.stops.length - 1]);

  if (routeLink && first && last) {
    routeLink.href = yandexRouteLink(route.stops);
  }

  routeTabs.forEach((tab, tabIndex) => {
    tab.classList.toggle('active', tabIndex === index);
  });

  if (!routeMap || typeof ymaps === 'undefined') return;

  routeMarkers.forEach((marker) => routeMap.geoObjects.remove(marker));
  routeMarkers = [];

  route.stops.forEach((id) => {
    const place = placeById(id);
    if (!place) return;

    const marker = new ymaps.Placemark([place.lat, place.lon], {
      hintContent: place.name,
      balloonContent: `<strong>${escapeHtml(place.name)}</strong><br>${escapeHtml(place.addr)}`
    }, {
      preset: 'islands#circleDot',
      iconColor: '#ffd166'
    });

    routeMap.geoObjects.add(marker);
    routeMarkers.push(marker);
  });

  const bounds = routeMap.geoObjects.getBounds();

  if (bounds) {
    routeMap.setBounds(bounds, { checkZoomRange: true, zoomMargin: [46, 46] });
  }
}

routeTabs.forEach((tab) => {
  tab.addEventListener('click', () => {
    drawRoute(Number(tab.dataset.index) || 0);
  });
});

// ======================================================================
// Карта мест: реальные достопримечательности
// ======================================================================
function initPlacesMap() {
  const element = document.getElementById('placesMap');
  const title = document.getElementById('mapTitle');
  const text = document.getElementById('mapText');
  const link = document.getElementById('mapLink');
  const coords = document.getElementById('mapCoords');

  if (!element) return;

  if (typeof ymaps === 'undefined') {
    mapFallback(
      element,
      'Карта не загрузилась (нужен интернет).<br>Все места перечислены в блоке «Вайбовые места».'
    );
    return;
  }

  ymaps.ready(() => {
    placesMap = new ymaps.Map(element, {
      center: [55.4395, 65.3425],
      zoom: 14,
      controls: ['zoomControl']
    });

    const map = placesMap;

    map.behaviors.disable('scrollZoom');

    const collection = new ymaps.GeoObjectCollection();

    PLACES.forEach((place) => {
      const marker = new ymaps.Placemark([place.lat, place.lon], {
        hintContent: place.name,
        balloonContent: `<strong>${escapeHtml(place.name)}</strong><br>${escapeHtml(place.addr)}`
      }, {
        preset: 'islands#circleDot',
        iconColor: '#ffd166'
      });

      marker.events.add('click', () => {
        if (title && text) {
          title.style.opacity = '0';
          text.style.opacity = '0';

          setTimeout(() => {
            title.textContent = place.name;
            text.textContent = `${place.addr}. ${place.info}`;
            title.style.opacity = '1';
            text.style.opacity = '1';
          }, 200);
        }

        if (link) {
          link.href = yandexPointLink(place.lat, place.lon);
          link.hidden = false;
        }

        if (coords) {
          coords.textContent = `${place.lat.toFixed(5)}, ${place.lon.toFixed(5)} · Яндекс.Карты`;
        }
      });

      collection.add(marker);
    });

    map.geoObjects.add(collection);

    const bounds = collection.getBounds();
    if (bounds) map.setBounds(bounds, { checkZoomRange: true, zoomMargin: [46, 46] });
  });
}

// ======================================================================
// Галерея и лайтбокс
// ======================================================================
const galleryItems = document.querySelectorAll('.gallery-item');

const lightbox = document.createElement('div');
lightbox.className = 'lightbox';
lightbox.innerHTML = `
  <div class="lightbox-content">
    <div class="lightbox-preview"></div>
    <h3 id="lightboxTitle"></h3>
    <p>Фотографии Кургана из открытых источников · Wikimedia Commons</p>
  </div>
`;

document.body.appendChild(lightbox);

const lightboxPreview = lightbox.querySelector('.lightbox-preview');
const lightboxTitle = document.getElementById('lightboxTitle');

galleryItems.forEach((item) => {
  item.addEventListener('click', () => {
    const preview = item.querySelector('img');
    if (!preview) return;

    lightboxPreview.style.backgroundImage = `url('${preview.src}')`;
    lightboxPreview.style.backgroundSize = 'cover';
    lightboxPreview.style.backgroundPosition = 'center';
    lightboxTitle.textContent = item.dataset.title || '';

    lightbox.classList.add('open');
  });
});

lightbox.addEventListener('click', (event) => {
  if (event.target === lightbox) {
    lightbox.classList.remove('open');
  }
});

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') {
    lightbox.classList.remove('open');
  }
});

// ======================================================================
// Анимированные счётчики
// ======================================================================
const counters = document.querySelectorAll('[data-count]');

const counterObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (!entry.isIntersecting) return;

    const element = entry.target;
    const target = parseInt(element.dataset.count, 10);
    const duration = 1600;
    const startTime = performance.now();

    function updateCounter(currentTime) {
      const progress = Math.min((currentTime - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);

      element.textContent = Math.round(target * eased);

      if (progress < 1) {
        requestAnimationFrame(updateCounter);
      }
    }

    requestAnimationFrame(updateCounter);
    counterObserver.unobserve(element);
  });
}, {
  threshold: 0.4
});

counters.forEach((counter) => counterObserver.observe(counter));

// ======================================================================
// Случайные истории
// ======================================================================
const randomButton = document.getElementById('randomButton');
const randomText = document.getElementById('randomText');

const stories = [
  'В 22:40 на улице Куйбышева остановился последний трамвай. Водитель достал термос, отпил и поехал дальше — уже не в депо, а домой.',
  'На площади Ленина двое грузили ёлку в газель. Один уронил перчатку, поднял и не надел: руки были заняты.',
  'В Городском саду на единственной занятой скамейке у пруда студентка заканчивала курсовую. Свет ноутбука был самым тёплым пятном в этом конце парка.',
  'У витрины на Пушкина женщина смотрела на пальто минуты две, потом достала телефон, сфотографировала ценник и ушла.',
  'В 00:15 у Тобола рыбак переставил удочку и сказал в телефон: «Ничего, я ещё немного». Ровно так же он говорил час назад.',
  'На Станционной охранник включил свет в третьем подъезде, понял, что не тот этаж, и сразу выключил.',
  'В 03:02 в окне напротив погас свет. Через минуту зажёгся в соседнем — кто-то дочитывал.',
  'В кафе на Гоголя официант снимал последний заказ и нарисовал на салфетке что-то вроде кота. Судя по всему, рисовал для себя.',
  'Такси на Гоголя ждало пассажира с включённым пробником. В радио читали поздравление для человека из Кургана, и водитель дослушал его до конца.',
  'В подъезде на Климова у дверей оставили пакет с продуктами и записку: «Берите, до утра испортится». К утру пакета не было.'
];

if (randomButton && randomText) {
  randomButton.addEventListener('click', () => {
    const randomStory = stories[Math.floor(Math.random() * stories.length)];

    randomText.style.opacity = '0';

    setTimeout(() => {
      randomText.textContent = randomStory;
      randomText.style.opacity = '1';
    }, 250);
  });
}

// ======================================================================
// Гостевая книга
// ======================================================================
const guestbookForm = document.getElementById('guestbookForm');
const guestName = document.getElementById('guestName');
const guestMessage = document.getElementById('guestMessage');
const guestbookList = document.getElementById('guestbookList');

function loadGuestNotes() {
  if (!guestbookList) return;

  const notes = readStorage('kurganGuestNotes', []);

  guestbookList.innerHTML = '';

  if (notes.length === 0) {
    guestbookList.innerHTML =
      '<div class="guest-empty">Пока здесь пусто. Ты можешь оставить первую запись.</div>';
    return;
  }

  notes.forEach((note) => {
    const noteElement = document.createElement('div');
    noteElement.className = 'guest-note';
    noteElement.innerHTML = `
      <strong>${escapeHtml(note.name)}</strong>
      <p>${escapeHtml(note.message)}</p>
    `;
    guestbookList.appendChild(noteElement);
  });
}

if (guestbookForm) {
  guestbookForm.addEventListener('submit', (event) => {
    event.preventDefault();

    const notes = readStorage('kurganGuestNotes', []);

    notes.unshift({
      name: guestName.value.trim(),
      message: guestMessage.value.trim()
    });

    writeStorage('kurganGuestNotes', notes);

    guestName.value = '';
    guestMessage.value = '';

    loadGuestNotes();
  });
}

loadGuestNotes();

// ======================================================================
// Вайбовые места: комментарий + фото + локация
// ======================================================================
const SPOTS_KEY = 'kurganSpots';
const LIKED_KEY = 'kurganLikedSpots';

const spotForm = document.getElementById('spotForm');
const spotName = document.getElementById('spotName');
const spotPlaceInput = document.getElementById('spotPlaceInput');
const spotText = document.getElementById('spotText');
const spotPhoto = document.getElementById('spotPhoto');
const spotPreview = document.getElementById('spotPreview');
const spotCoords = document.getElementById('spotCoords');
const spotStatus = document.getElementById('spotStatus');
const spotsList = document.getElementById('spotsList');

let pendingPhoto = '';
let lastGeocode = { query: '', result: null };

function loadSpots() {
  return readStorage(SPOTS_KEY, []);
}

// Ищем координаты места, написанного своими словами (Nominatim / OpenStreetMap)
async function geocodePlace(query) {
  const clean = String(query || '').trim();

  if (!clean) return null;
  if (lastGeocode.query === clean) return lastGeocode.result;

  const url = 'https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=ru&q='
    + encodeURIComponent(`${clean}, Курган, Курганская область`);

  let result = null;

  try {
    const response = await fetch(url, { headers: { 'Accept-Language': 'ru' } });
    const data = await response.json();

    if (Array.isArray(data) && data.length) {
      result = { lat: Number(data[0].lat), lon: Number(data[0].lon) };
    }
  } catch (error) {
    result = null;
  }

  lastGeocode = { query: clean, result };
  return result;
}

function compressImage(file, maxSide = 1400, quality = 0.72) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onerror = () => reject(new Error('Не удалось прочитать файл'));
    reader.onload = () => {
      const image = new Image();

      image.onerror = () => reject(new Error('Не удалось открыть изображение'));
      image.onload = () => {
        let width = image.width;
        let height = image.height;
        const scale = Math.min(1, maxSide / Math.max(width, height));

        width = Math.round(width * scale);
        height = Math.round(height * scale);

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        const context = canvas.getContext('2d');
        context.drawImage(image, 0, 0, width, height);

        resolve(canvas.toDataURL('image/jpeg', quality));
      };

      image.src = reader.result;
    };

    reader.readAsDataURL(file);
  });
}

function renderSpots() {
  if (!spotsList) return;

  const spots = loadSpots();
  const likedIds = readStorage(LIKED_KEY, []);

  if (spots.length === 0) {
    spotsList.innerHTML = `
      <li class="spots-empty">
        Пока нет ни одного места. Напиши своё — с фото и историей — и оно появится здесь.
      </li>
    `;
    return;
  }

  spotsList.innerHTML = spots.map((spot) => {
    const placeName = spot.place || 'Своё место';
    const liked = likedIds.indexOf(spot.id) !== -1;
    const likes = Number(spot.likes || 0) + (liked ? 1 : 0);
    const date = new Date(spot.ts).toLocaleDateString('ru-RU');
    const hasCoords = typeof spot.lat === 'number' && typeof spot.lon === 'number';

    const media = spot.photo
      ? `<img src="${spot.photo}" alt="${escapeHtml(placeName)}">`
      : '<div class="spot-no-photo">Фото не приложено</div>';

    const coordLink = hasCoords
      ? `<a href="${yandexPointLink(spot.lat, spot.lon)}" target="_blank" rel="noopener">
           📍 ${spot.lat.toFixed(5)}, ${spot.lon.toFixed(5)}
         </a>`
      : `<span class="spot-no-coords">координаты не найдены</span>`;

    return `
      <li class="spot-card" data-id="${escapeHtml(spot.id)}">
        ${media}
        <div class="spot-body">
          <div class="spot-head">
            <strong>${escapeHtml(spot.name)}</strong>
            <span class="spot-date">${date}</span>
          </div>
          <h4 class="spot-place">${escapeHtml(placeName)}</h4>
          <p class="spot-text">${escapeHtml(spot.text)}</p>
          <div class="spot-meta">
            ${coordLink}
            <button type="button" class="spot-like${liked ? ' liked' : ''}" data-action="like">
              ❤ ${likes}
            </button>
            <button type="button" class="spot-del" data-action="delete">Удалить</button>
          </div>
        </div>
      </li>
    `;
  }).join('');
}

if (spotForm && spotPlaceInput) {
  spotPlaceInput.addEventListener('blur', async () => {
    const query = spotPlaceInput.value.trim();
    if (!query || !spotCoords) return;

    spotCoords.textContent = 'Ищу координаты места...';
    const found = await geocodePlace(query);

    spotCoords.textContent = found
      ? `${found.lat.toFixed(5)}, ${found.lon.toFixed(5)} · найдено по названию`
      : 'Координаты не нашлись — запись сохранится и без них';
  });
}

if (spotPhoto) {
  spotPhoto.addEventListener('change', async () => {
    const file = spotPhoto.files && spotPhoto.files[0];

    if (!file) {
      pendingPhoto = '';
      if (spotPreview) spotPreview.hidden = true;
      return;
    }

    if (spotStatus) spotStatus.textContent = 'Обрабатываю фото...';

    try {
      pendingPhoto = await compressImage(file);

      if (spotPreview) {
        spotPreview.src = pendingPhoto;
        spotPreview.hidden = false;
      }

      if (spotStatus) {
        spotStatus.textContent = `Фото готово · ${Math.round(pendingPhoto.length / 1024)} КБ`;
      }
    } catch (error) {
      pendingPhoto = '';
      if (spotStatus) spotStatus.textContent = 'Не удалось обработать это фото. Попробуй другое.';
    }
  });
}

if (spotForm) {
  spotForm.addEventListener('submit', async (event) => {
    event.preventDefault();

    const place = spotPlaceInput ? spotPlaceInput.value.trim() : '';
    if (!place) return;

    if (spotStatus) spotStatus.textContent = 'Определяю координаты места...';

    const coords = await geocodePlace(place);

    const spots = loadSpots();

    spots.unshift({
      id: `spot_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      name: spotName.value.trim(),
      place: place,
      text: spotText.value.trim(),
      photo: pendingPhoto,
      lat: coords ? coords.lat : null,
      lon: coords ? coords.lon : null,
      likes: 0,
      ts: Date.now()
    });

    const saved = writeStorage(SPOTS_KEY, spots);

    if (!saved) {
      if (spotStatus) {
        spotStatus.textContent = 'Хранилище браузера переполнилось. Удали пару мест с фото и попробуй снова.';
      }
      return;
    }

    spotName.value = '';
    spotText.value = '';
    spotPhoto.value = '';
    pendingPhoto = '';

    if (spotPlaceInput) spotPlaceInput.value = '';
    if (spotPreview) spotPreview.hidden = true;
    if (spotCoords) spotCoords.textContent = 'Координаты места определятся автоматически';
    if (spotStatus) {
      spotStatus.textContent = coords
        ? 'Место добавлено, координаты найдены. Спасибо!'
        : 'Место добавлено (координаты не нашлись). Спасибо!';
    }

    renderSpots();
  });
}

if (spotsList) {
  spotsList.addEventListener('click', (event) => {
    const button = event.target.closest('button[data-action]');
    if (!button) return;

    const card = button.closest('.spot-card');
    if (!card) return;

    const id = card.dataset.id;
    const spots = loadSpots();
    const likedIds = readStorage(LIKED_KEY, []);

    if (button.dataset.action === 'like') {
      const position = likedIds.indexOf(id);

      if (position === -1) {
        likedIds.push(id);
      } else {
        likedIds.splice(position, 1);
      }

      writeStorage(LIKED_KEY, likedIds);
      renderSpots();
    }

    if (button.dataset.action === 'delete') {
      if (!confirm('Удалить эту запись?')) return;

      writeStorage(SPOTS_KEY, spots.filter((spot) => spot.id !== id));

      const likedPosition = likedIds.indexOf(id);
      if (likedPosition !== -1) {
        likedIds.splice(likedPosition, 1);
        writeStorage(LIKED_KEY, likedIds);
      }

      renderSpots();
    }
  });
}

renderSpots();

// ======================================================================
// Инициализация карт
// ======================================================================
initRouteMap(() => drawRoute(0));
initPlacesMap();

let resizeTimer = null;

window.addEventListener('resize', () => {
  if (!routeMap && !placesMap) return;

  window.clearTimeout(resizeTimer);

  resizeTimer = window.setTimeout(() => {
    if (routeMap && routeMap.container) routeMap.container.fitToViewport();
    if (placesMap && placesMap.container) placesMap.container.fitToViewport();
  }, 200);
});
